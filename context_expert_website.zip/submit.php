<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $school = htmlspecialchars($_POST["school"]);
    $course = htmlspecialchars($_POST["course"]);
    $message = htmlspecialchars($_POST["message"]);

    $entry = "Name: $name\nEmail: $email\nSchool: $school\nCourse: $course\nMessage: $message\n---\n";

    file_put_contents("registrations.txt", $entry, FILE_APPEND);

    header("Location: thankyou.html");
    exit();
}
?>