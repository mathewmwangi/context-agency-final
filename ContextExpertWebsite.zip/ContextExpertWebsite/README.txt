Context Expert Agencies – Student Attachment Website
----------------------------------------------------

This project was created using HTML and CSS inside Visual Studio Code.

Features:
- Homepage with call-to-action
- Courses page with detailed information
- Online registration form (with CV upload)
- Map to our Ruiru office
- Success message after registration
- Fully responsive and simple to maintain

Developer:
Mathew Brian Mwangi Wambugu
Student, Kisii University
2025 Attachment Project
